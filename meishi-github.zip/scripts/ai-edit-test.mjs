/* AI による内容編集（提案 → 確認 → 適用）のテスト。
 *
 * 方針の核は「AI は提案まで、適用は人間が確認」。
 * そのため以下を重点的に検証する:
 *   1. 提案段階では DB が書き換わらない
 *   2. 許可リスト外の項目は書き換えられない
 *   3. 「適用」してはじめて反映される
 *   4. キャンセルすると何も変わらない
 *   5. 対象が曖昧なときは推測せず候補を返す
 *
 * 実 DB を使うため、作成したテスト用カードは必ず後片付けする。
 */
import { JSDOM, VirtualConsole } from 'jsdom'
import fs from 'node:fs'

const BASE = 'http://localhost:3000'
let failed = 0
function check(name, cond, extra = '') {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  <-- ' + extra}`)
  if (!cond) failed += 1
}
const post = async (path, body) => {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  return { status: res.status, data: await res.json() }
}

/* ================= テスト用カードを用意 ================= */
const created = await post('/api/cards', {
  name: 'AI編集検証 太郎',
  nameKana: 'えーあいへんしゅうけんしょう たろう',
  company: '編集検証株式会社',
  department: '検証部',
  position: '平社員',
  email: 'edit-test@example.com',
  memo: '元のメモ',
  tags: ['既存タグ'],
})
check('テスト用カードを作成できる', created.status === 201, JSON.stringify(created.data).slice(0, 120))
const cardId = created.data.id
const cleanup = async () => {
  await fetch(`${BASE}/api/cards/${cardId}`, { method: 'DELETE' })
}
const getCard = async () => (await (await fetch(`${BASE}/api/cards/${cardId}`)).json())

/* ================= 差分の生成（書き換えない） ================= */
console.log('\n--- 差分の生成 ---')
const dry = await post('/api/assistant/apply', {
  mode: 'update',
  cardId,
  changes: { department: '営業部', position: '課長' },
  dryRun: true,
})
check('dryRun が成功する', dry.status === 200 && dry.data.dryRun === true, JSON.stringify(dry.data).slice(0, 120))
check('2件の差分が返る', dry.data.preview.fieldDiffs.length === 2, `${dry.data.preview.fieldDiffs.length}`)
check('差分に変更前が入る', dry.data.preview.fieldDiffs.some((d) => d.before === '検証部'))
check('差分に変更後が入る', dry.data.preview.fieldDiffs.some((d) => d.after === '営業部'))

const untouched = await getCard()
check('dryRun では DB が書き換わらない', untouched.department === '検証部' && untouched.position === '平社員', `${untouched.department}/${untouched.position}`)

/* ================= 許可リストの強制 ================= */
console.log('\n--- 許可リスト（安全側の検証） ---')
const evil = await post('/api/assistant/apply', {
  mode: 'update',
  cardId,
  changes: { id: 999, created_at: 'HACKED', updated_at: 'HACKED', password: 'x', position: '部長' },
  dryRun: true,
})
check('許可外の項目は差分に出ない', evil.data.preview.fieldDiffs.length === 1 && evil.data.preview.fieldDiffs[0].field === 'position', JSON.stringify(evil.data.preview.fieldDiffs))
check('id は書き換わらない', evil.data.card.id === cardId)

/* ================= 適用 ================= */
console.log('\n--- 適用 ---')
const applied = await post('/api/assistant/apply', {
  mode: 'update',
  cardId,
  changes: { department: '営業部', position: '課長', addTags: ['新タグ'] },
})
check('適用が成功する', applied.data.ok === true && applied.data.changed === true, JSON.stringify(applied.data).slice(0, 120))
const afterApply = await getCard()
check('部署が反映される', afterApply.department === '営業部', afterApply.department)
check('役職が反映される', afterApply.position === '課長', afterApply.position)
check('タグが追加される', afterApply.tags.includes('新タグ') && afterApply.tags.includes('既存タグ'), JSON.stringify(afterApply.tags))

/* ================= 変化なしの扱い ================= */
console.log('\n--- 変化なし ---')
const same = await post('/api/assistant/apply', { mode: 'update', cardId, changes: { department: '営業部' } })
check('同じ値なら changed=false', same.data.changed === false, JSON.stringify(same.data).slice(0, 100))

/* ================= 一括タグ操作 ================= */
console.log('\n--- 一括タグ操作 ---')
const bulk = await post('/api/assistant/apply', {
  mode: 'bulk_tag',
  tagOp: { tag: '一括検証', op: 'add' },
  cardIds: [cardId],
})
check('一括付与できる', bulk.data.updated === 1, JSON.stringify(bulk.data))
const afterBulk = await getCard()
check('一括でタグが付く', afterBulk.tags.includes('一括検証'), JSON.stringify(afterBulk.tags))

const bulkAgain = await post('/api/assistant/apply', {
  mode: 'bulk_tag',
  tagOp: { tag: '一括検証', op: 'add' },
  cardIds: [cardId],
})
check('同じ一括操作は冪等（0件）', bulkAgain.data.updated === 0, JSON.stringify(bulkAgain.data))

const removed = await post('/api/assistant/apply', {
  mode: 'bulk_tag',
  tagOp: { tag: '一括検証', op: 'remove' },
  cardIds: [cardId],
})
check('一括解除できる', removed.data.updated === 1, JSON.stringify(removed.data))

/* ================= 対象の解決 ================= */
console.log('\n--- 対象の解決 ---')
const notFound = await post('/api/assistant/apply', { mode: 'update', cardId: 999999, changes: { department: 'X' } })
check('存在しないIDは404', notFound.status === 404, `${notFound.status}`)

const badMode = await post('/api/assistant/apply', { mode: 'drop_table' })
check('不正な mode は400', badMode.status === 400, `${badMode.status}`)

const badBulk = await post('/api/assistant/apply', { mode: 'bulk_tag', tagOp: { tag: '', op: 'add' }, cardIds: [cardId] })
check('タグ未指定は400', badBulk.status === 400, `${badBulk.status}`)

/* ================= UI: 提案カードと適用 / キャンセル ================= */
console.log('\n--- UI: 提案カード ---')
const html = await (await fetch(BASE + '/')).text()
const appJs = fs.readFileSync('public/static/app.js', 'utf8')
const css = fs.readFileSync('public/static/style.css', 'utf8')

const errors = []
const vc = new VirtualConsole()
vc.on('jsdomError', (e) => errors.push('jsdomError: ' + e.message))
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')))

const dom = new JSDOM(html, { url: BASE + '/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc })
const { window } = dom
const doc = window.document
const style = doc.createElement('style')
style.textContent = css
doc.head.appendChild(style)

window.fetch = (input, init) => {
  const url = typeof input === 'string' && input.startsWith('/') ? BASE + input : input
  return fetch(url, init)
}
window.navigator.clipboard = { writeText: async () => {} }
window.confirm = () => true

const script = doc.createElement('script')
script.textContent = appJs
doc.body.appendChild(script)

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const q = (s) => doc.querySelector(s)
const qa = (s) => Array.from(doc.querySelectorAll(s))
await wait(1400)

// 提案カードを直接描画して、適用/キャンセルの DOM 契約を確かめる
window.eval(`
  (function () {
    const preview = {
      cardId: ${cardId},
      card: { id: ${cardId}, name: 'AI編集検証 太郎', company: '編集検証株式会社' },
      fieldDiffs: [{ field: 'department', label: '部署', before: '営業部', after: '広報部' }],
      tagsAdd: [], tagsRemove: [], favorite: null, hasChange: true
    };
    openAi();
    appendProposal(preview, { changes: { department: '広報部' } });
  })();
`)
await wait(400)

check('提案カードが描画される', qa('.ai-proposal').length === 1, `${qa('.ai-proposal').length}`)
check('差分に変更前が出る', (q('.ai-diff-before')?.textContent || '').includes('営業部'), q('.ai-diff-before')?.textContent)
check('差分に変更後が出る', (q('.ai-diff-after')?.textContent || '').includes('広報部'), q('.ai-diff-after')?.textContent)
check('適用ボタンがある', qa('[data-apply]').length === 1)
check('キャンセルボタンがある', qa('[data-cancel]').length === 1)
check('「適用するまで保存されない」と明示される', (q('.ai-proposal .ai-note')?.textContent || '').includes('適用するまで'), q('.ai-proposal .ai-note')?.textContent)

/* --- キャンセルは何も変えない --- */
const beforeCancel = await getCard()
q('[data-cancel]').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(500)
const afterCancel = await getCard()
check('キャンセルで DB が変わらない', JSON.stringify(beforeCancel) === JSON.stringify(afterCancel))
check('キャンセル後は操作ボタンが消える', qa('.ai-proposal [data-apply]').length === 0)
check('キャンセルしたことが示される', (q('.ai-proposal')?.textContent || '').includes('キャンセル'), q('.ai-proposal')?.textContent?.slice(-60))

/* --- 適用すると反映される --- */
window.eval(`
  (function () {
    const preview = {
      cardId: ${cardId},
      card: { id: ${cardId}, name: 'AI編集検証 太郎', company: '編集検証株式会社' },
      fieldDiffs: [{ field: 'department', label: '部署', before: '営業部', after: '広報部' }],
      tagsAdd: [], tagsRemove: [], favorite: null, hasChange: true
    };
    appendProposal(preview, { changes: { department: '広報部' } });
  })();
`)
await wait(400)
q('[data-apply]').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(1200)

const afterUiApply = await getCard()
check('適用で DB に反映される', afterUiApply.department === '広報部', afterUiApply.department)
check('適用後は操作ボタンが消える', qa('.ai-proposal [data-apply]').length === 0)
check('適用したことが示される', qa('.ai-proposal.is-done').length >= 1, `${qa('.ai-proposal.is-done').length}`)

/* ================= 後片付け ================= */
await cleanup()
const gone = await fetch(`${BASE}/api/cards/${cardId}`)
check('後片付けで削除される', gone.status === 404, `${gone.status}`)

console.log('\nJSエラー:', errors.length ? errors.slice(0, 5) : 'なし')
if (errors.length) failed += 1
console.log(failed === 0 ? 'すべてのAI編集テストに合格' : `${failed} 件失敗`)
process.exit(failed ? 1 : 0)
