/* jsdom で実際のページを読み込み、フロントエンドを走らせて UI を検証する。
   期待値は API から動的に取得する（実データ件数を決め打ちしない）。 */
import { JSDOM, VirtualConsole } from 'jsdom'
import fs from 'node:fs'

const BASE = 'http://localhost:3000'

const meta = await (await fetch(BASE + '/api/meta')).json()
const all = await (await fetch(BASE + '/api/cards?sort=updated')).json()
const TOTAL = meta.total
const FAVS = meta.favorites

const html = await (await fetch(BASE + '/')).text()

const errors = []
const vc = new VirtualConsole()
vc.on('jsdomError', (e) => errors.push('jsdomError: ' + e.message))
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')))

const dom = new JSDOM(html, {
  url: BASE + '/',
  runScripts: 'dangerously',
  pretendToBeVisual: true,
  virtualConsole: vc,
})
const { window } = dom

window.fetch = (input, init) => {
  const url = typeof input === 'string' && input.startsWith('/') ? BASE + input : input
  return fetch(url, init)
}
window.navigator.clipboard = { writeText: async () => {} }
window.confirm = () => true

const appJs = fs.readFileSync('public/static/app.js', 'utf8')
const script = window.document.createElement('script')
script.textContent = appJs
window.document.body.appendChild(script)

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const doc = window.document
const q = (s) => doc.querySelector(s)
const qa = (s) => Array.from(doc.querySelectorAll(s))

let failed = 0
function check(name, cond, extra = '') {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  <-- ' + extra}`)
  if (!cond) failed += 1
}

await wait(1400)

console.log(`--- 前提: DB ${TOTAL}件 / お気に入り ${FAVS}件 ---`)

/* 1. 初期描画 */
check(`名刺カードが描画される (${TOTAL}件)`, qa('.card').length === TOTAL, `got ${qa('.card').length}`)
check('件数表示が更新される', (q('#result-count')?.textContent || '').includes(`${TOTAL}件`), q('#result-count')?.textContent)
check('サイドバーの総数', q('#count-all')?.textContent === String(TOTAL), q('#count-all')?.textContent)
check('お気に入り件数', q('#count-fav')?.textContent === String(FAVS), q('#count-fav')?.textContent)
check('タグチップが生成される', qa('#tag-filters .chip').length > 0, `${qa('#tag-filters .chip').length}`)
check('会社リストが生成される', qa('#company-filters .company-item').length === meta.companies.length, `${qa('#company-filters .company-item').length}`)
check('空状態は非表示', q('#empty-state').hidden === true)

/* 2. 検索 */
const search = q('#search-input')
const target = all.cards[0]
const keyword = target.name.split(/\s+/)[0]
search.value = keyword
search.dispatchEvent(new window.Event('input', { bubbles: true }))
await wait(900)
const expectSearch = (await (await fetch(`${BASE}/api/cards?q=${encodeURIComponent(keyword)}`)).json()).total
check(`検索で絞り込める (「${keyword}」= ${expectSearch}件)`, qa('.card').length === expectSearch, `got ${qa('.card').length}`)
check('検索見出しが変わる', (q('#result-title')?.textContent || '').includes(keyword), q('#result-title')?.textContent)

search.value = ''
search.dispatchEvent(new window.Event('input', { bubbles: true }))
await wait(900)
check('検索クリアで全件に戻る', qa('.card').length === TOTAL, `got ${qa('.card').length}`)

/* 3. タグフィルタ（renderSidebar が DOM を作り直すので毎回引き直す） */
const tagName = meta.tags[0]
const tagChip = (name) => qa('#tag-filters .chip').find((c) => c.dataset.tag === name)
const expectTag = (await (await fetch(`${BASE}/api/cards?tag=${encodeURIComponent(tagName)}`)).json()).total
tagChip(tagName)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check(`タグフィルタが機能する (#${tagName} = ${expectTag}件)`, qa('.card').length === expectTag, `got ${qa('.card').length}`)
check('タグチップが active になる', tagChip(tagName)?.classList.contains('is-active'))

tagChip(tagName)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check('タグ解除で全件に戻る', qa('.card').length === TOTAL, `got ${qa('.card').length}`)

/* 4. お気に入りフィルタ（タグ条件は解除されていること） */
qa('.side-item').find((b) => b.dataset.filter === 'favorite')?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check(`お気に入りフィルタが機能する (${FAVS}件)`, qa('.card').length === FAVS, `got ${qa('.card').length}`)
check('見出しがお気に入りになる', /お気に入り/.test(q('#result-title')?.textContent || ''), q('#result-title')?.textContent)
qa('.side-item').find((b) => b.dataset.filter === 'all')?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check('すべてに戻る', qa('.card').length === TOTAL, `got ${qa('.card').length}`)

/* 5. ソート */
const sort = q('#sort-select')
const apiSorted = await (await fetch(BASE + '/api/cards?sort=name')).json()
sort.value = 'name'
sort.dispatchEvent(new window.Event('change', { bubbles: true }))
await wait(900)
const first = (qa('.card-name')[0]?.textContent || '').trim()
check(`氏名順ソートがAPIと一致 (先頭: ${apiSorted.cards[0].name})`, first.includes(apiSorted.cards[0].name.split(/\s+/)[0]), first)
sort.value = 'updated'
sort.dispatchEvent(new window.Event('change', { bubbles: true }))
await wait(900)

/* 6. 詳細ドロワー（連絡先を持つ名刺でコピーボタンを確認） */
const rich = all.cards.find((c) => c.email) || all.cards[0]
doc.querySelector(`.card[data-id="${rich.id}"]`)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(400)
check('ドロワーが開く', q('#detail-drawer').classList.contains('is-open'))
const detailText = q('#detail-content')?.textContent || ''
check('詳細に氏名が出る', detailText.includes(rich.name), detailText.slice(0, 60))
check('詳細にコピーボタン', qa('[data-copy]').length > 0, `${qa('[data-copy]').length}`)
q('#drawer-close')?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(300)
check('ドロワーが閉じる', !q('#detail-drawer').classList.contains('is-open'))

/* 7. 新規フォーム → 保存 */
const uniqueName = `UI検証 ${Date.now()}`
q('#new-card-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(200)
check('フォームが開く', q('#modal-backdrop').hidden === false)
check('新規時は交換日が入る', q('#field-metAt').value.length === 10, q('#field-metAt').value)

q('#field-name').value = uniqueName
q('#field-company').value = '検証オフィス'
q('#field-tags').value = 'UI, 検証'
q('#field-email').value = 'hanako@example.com'
q('#card-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }))
await wait(1500)
check('保存後にフォームが閉じる', q('#modal-backdrop').hidden === true)
check(`保存後に${TOTAL + 1}件になる`, qa('.card').length === TOTAL + 1, `got ${qa('.card').length}`)

/* 8. バリデーション */
q('#new-card-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(150)
q('#field-name').value = ''
q('#card-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }))
await wait(400)
check('氏名必須エラーが出る', q('#form-error').hidden === false, q('#form-error').textContent)
q('#modal-cancel').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(200)

/* 9. 作成した名刺を削除（後片付けも兼ねる） */
const created = (await (await fetch(`${BASE}/api/cards?q=${encodeURIComponent(uniqueName)}`)).json()).cards[0]
check('作成した名刺がAPIに存在する', Boolean(created), uniqueName)
if (created) {
  doc.querySelector(`.card[data-id="${created.id}"]`)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
  await wait(400)
  q('#drawer-delete')?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
  await wait(1500)
}
const afterDelete = await (await fetch(BASE + '/api/cards')).json()
check(`削除後に${TOTAL}件に戻る`, afterDelete.total === TOTAL, `got ${afterDelete.total}`)
check('UIも元の件数に戻る', qa('.card').length === TOTAL, `got ${qa('.card').length}`)

/* 10. 星ボタン */
const star = qa('.card .star-btn')[0]
star?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(1300)
const favAfter = Number(q('#count-fav').textContent)
check('星クリックでお気に入り件数が変わる', favAfter === FAVS + 1 || favAfter === FAVS - 1, `${favAfter} (before ${FAVS})`)
// 元に戻す
qa('.card .star-btn')[0]?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(1300)
check('星の再クリックで元に戻る', Number(q('#count-fav').textContent) === FAVS, q('#count-fav').textContent)

console.log('\nJSエラー:', errors.length ? errors.slice(0, 5) : 'なし')
if (errors.length) failed += 1
console.log(failed === 0 ? 'すべてのUIテストに合格' : `${failed} 件失敗`)
process.exit(failed ? 1 : 0)
