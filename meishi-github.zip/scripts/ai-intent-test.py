#!/usr/bin/env python3
"""AIの意図解釈プロンプトを実データで検証する。"""
import json
import os
import subprocess
import sys
import urllib.request

BASE = "http://localhost:3000"
API_KEY = os.environ["OPENAI_API_KEY"]
BASE_URL = os.environ["OPENAI_BASE_URL"]

SYSTEM = """あなたは名刺管理アプリの検索アシスタントです。ユーザーの自然言語の指示を、JSON形式の検索条件に変換してください。

必ず次のJSONスキーマのみを出力してください（前後に説明文やコードブロックを付けない）:
{
  "intent": "filter" | "answer" | "export" | "help",
  "filters": {
    "q": string,
    "department": string,
    "company": string,
    "tag": string,
    "favorite": boolean,
    "sort": "updated" | "name" | "company" | "met"
  },
  "message": string
}

重要なルール:
- 「広報部署だけ」のように部署を指定されたら department に入れる。部署名は語彙から最も近いものを選ぶ。
- 「まとめて」「一覧」「見せて」「絞り込んで」は intent="filter"。
- 件数を聞かれたら intent="answer"。
- 「CSVで出して」は intent="export"。
- 該当が無ければ無理に作らず filters は空のままにする。
- department / tag / company は必ず語彙にある値を使う。"""


def get_vocab():
    """実DBから部署・会社・タグの語彙を集める"""
    cards = json.load(urllib.request.urlopen(f"{BASE}/api/cards"))["cards"]
    depts = sorted({c["department"] for c in cards if c["department"]})
    companies = sorted({c["company"] for c in cards if c["company"]})
    tags = sorted({t for c in cards for t in c["tags"]})
    return {"departments": depts, "companies": companies, "tags": tags, "count": len(cards)}


def ask(text, vocab, model="gpt-5-nano"):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {
                "role": "user",
                "content": "# 語彙\n" + json.dumps(vocab, ensure_ascii=False) + "\n\n# 指示\n" + text,
            },
        ],
        "response_format": {"type": "json_object"},
        "max_completion_tokens": 900,
    }
    req = urllib.request.Request(
        f"{BASE_URL}/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=90) as r:
        d = json.load(r)
    if "error" in d:
        return {"error": d["error"]}
    content = d["choices"][0]["message"]["content"]
    try:
        return json.loads(content)
    except Exception:
        return {"raw": content}


def main():
    vocab = get_vocab()
    print("=== 語彙 ===")
    print("部署:", vocab["departments"][:8])
    print("会社数:", len(vocab["companies"]), "| タグ数:", len(vocab["tags"]))
    print()

    cases = [
        "広報部署だけまとめて",
        "営業の人だけ見せて",
        "お気に入りだけ",
        "SaaSに関わる人を全部",
        "名刺は何枚ある？",
        "CSVで出して",
        "株式会社ライトスピードの人",
        "というか、デザイン系の人いたっけ",
        "採用やってる人をあいうえお順で",
    ]
    for text in cases:
        r = ask(text, vocab)
        if "error" in r:
            print(f"▶ {text}\n  ERROR: {r['error']}\n")
            continue
        f = r.get("filters", {})
        active = {k: v for k, v in f.items() if v not in ("", False, None) and k != "sort"}
        print(f"▶ {text}")
        print(f"  intent={r.get('intent')} filters={active}")
        print(f"  msg={r.get('message')}")
        print()


if __name__ == "__main__":
    main()
