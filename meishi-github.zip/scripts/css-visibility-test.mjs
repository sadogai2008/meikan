/* CSSカスケードを含めた「実際に見えているか」を検証する
   hidden 属性は UA スタイルシートの display:none だが、
   作者CSSの display 宣言に負けるため、computed style で確認する必要がある。 */
import { JSDOM } from 'jsdom'
import fs from 'node:fs'

const BASE = 'http://localhost:3000'
const html = await (await fetch(BASE + '/')).text()
const css = fs.readFileSync('public/static/style.css', 'utf8')
const appJs = fs.readFileSync('public/static/app.js', 'utf8')

const dom = new JSDOM(html, { url: BASE + '/', runScripts: 'dangerously', pretendToBeVisual: true })
const { window } = dom

// 作者CSSを読み込ませる（これがないと cascade が再現できない）
const style = window.document.createElement('style')
style.textContent = css
window.document.head.appendChild(style)

window.fetch = (input, init) =>
  fetch(typeof input === 'string' && input.startsWith('/') ? BASE + input : input, init)
window.navigator.clipboard = { writeText: async () => {} }
window.confirm = () => true

const wait = (ms) => new Promise((r) => setTimeout(r, ms))

const doc = window.document
const q = (s) => doc.querySelector(s)
const qa = (s) => Array.from(doc.querySelectorAll(s))
const display = (sel) => window.getComputedStyle(q(sel)).display

let failed = 0
function check(name, cond, extra = '') {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  <-- ' + extra}`)
  if (!cond) failed += 1
}

/* ---- JS を実行する前（初期HTML状態）---- */
console.log('--- 初期表示（JS実行前）---')
check('モーダルは非表示 (display:none)', display('#modal-backdrop') === 'none', `display=${display('#modal-backdrop')}`)
check('空状態は非表示 (display:none)', display('#empty-state') === 'none', `display=${display('#empty-state')}`)
check('トースト非表示 (display:none)', display('#toast') === 'none', `display=${display('#toast')}`)
check('ドロワーオーバーレイ非表示 (display:none)', display('#drawer-overlay') === 'none', `display=${display('#drawer-overlay')}`)

/* ---- アプリ起動 ---- */
const script = doc.createElement('script')
script.textContent = appJs
doc.body.appendChild(script)
await wait(1300)

console.log('\n--- アプリ起動後（12件表示）---')
check('カード12件が描画される', qa('.card').length === 12, `${qa('.card').length}`)
check('空状態は非表示のまま', display('#empty-state') === 'none', `display=${display('#empty-state')}`)
check('モーダルは非表示のまま (display:none)', display('#modal-backdrop') === 'none', `display=${display('#modal-backdrop')}`)

/* ---- フォームを開く ---- */
q('#new-card-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(250)
console.log('\n--- 「名刺を追加」を押す ---')
check('モーダルが表示される (display:flex)', display('#modal-backdrop') === 'flex', `display=${display('#modal-backdrop')}`)

/* ---- キャンセルで閉じる ---- */
q('#modal-cancel').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(300)
console.log('\n--- キャンセル押下 ---')
check('キャンセルでモーダルが閉じる (display:none)', display('#modal-backdrop') === 'none', `display=${display('#modal-backdrop')}`)
check('body のスクロールロックが解除される', !doc.body.classList.contains('no-scroll'))

/* ---- バツボタンでも閉じる ---- */
q('#new-card-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(200)
q('#modal-close').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(250)
check('✕ボタンでモーダルが閉じる (display:none)', display('#modal-backdrop') === 'none', `display=${display('#modal-backdrop')}`)

/* ---- Escでも閉じる ---- */
q('#new-card-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(200)
doc.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }))
await wait(250)
check('Escでモーダルが閉じる (display:none)', display('#modal-backdrop') === 'none', `display=${display('#modal-backdrop')}`)

/* ---- 空状態の表示切替 ---- */
q('#search-input').value = 'zzz存在しないzzz'
q('#search-input').dispatchEvent(new window.Event('input', { bubbles: true }))
await wait(900)
console.log('\n--- 該当0件の検索 ---')
check('0件時に空状態が表示される (display:flex)', display('#empty-state') === 'flex', `display=${display('#empty-state')}`)
check('0件時はカードが無い', qa('.card').length === 0, `${qa('.card').length}`)

q('#search-input').value = ''
q('#search-input').dispatchEvent(new window.Event('input', { bubbles: true }))
await wait(900)
check('検索クリアで空状態が再び非表示', display('#empty-state') === 'none', `display=${display('#empty-state')}`)
check('カードが12件に戻る', qa('.card').length === 12, `${qa('.card').length}`)

console.log(`\n${failed === 0 ? 'すべての表示状態テストに合格' : failed + ' 件失敗'}`)
process.exit(failed ? 1 : 0)
