/* CSV パーサの単体テスト
   実際の名刺管理ツールが吐きそうな「表記ゆれだらけのCSV」で検証する。 */
import { parseCsv, csvToCards, duplicateKey } from '../src/csv.ts'

let failed = 0
function check(name, cond, extra = '') {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  <-- ' + extra}`)
  if (!cond) failed += 1
}

/* ---- 1. RFC4180 の基本 ---- */
const basic = parseCsv('a,b,c\n1,2,3')
check('基本の3列×2行', basic.length === 2 && basic[1].join(',') === '1,2,3', JSON.stringify(basic))

const quoted = parseCsv('name,note\n"佐藤, 健太","彼は""重要""顧客"')
check('引用符内のカンマ', quoted[1][0] === '佐藤, 健太', JSON.stringify(quoted[1]))
check('"" エスケープ', quoted[1][1] === '彼は"重要"顧客', JSON.stringify(quoted[1][1]))

const multiline = parseCsv('name,memo\n鈴木,"1行目\n2行目"')
check('引用符内の改行', multiline[1][1] === '1行目\n2行目', JSON.stringify(multiline[1][1]))

const crlf = parseCsv('a,b\r\n1,2\r\n3,4')
check('CRLF改行', crlf.length === 3 && crlf[2][0] === '3', JSON.stringify(crlf))

const bom = parseCsv('\uFEFFname,company\n田中,テスト社')
check('BOM付き（Excel出力）', bom[0][0] === 'name', JSON.stringify(bom[0]))

const trailing = parseCsv('a,b\n1,2\n')
check('末尾改行で空行を作らない', trailing.length === 2, `${trailing.length}`)

const emptyCells = parseCsv('a,b,c\n1,,3')
check('空セルを保持', emptyCells[1].length === 3 && emptyCells[1][1] === '', JSON.stringify(emptyCells[1]))

/* ---- 2. 日本語ヘッダのマッピング ---- */
const jp = csvToCards(`氏名,ふりがな,会社名,部署,役職,メールアドレス,電話番号,携帯電話,Webサイト,住所,タグ,メモ,お気に入り,名刺交換日
鈴木 一郎,すずき いちろう,株式会社ライトスピード,営業本部,執行役員,ichiro@example.com,03-1234-5678,090-1234-5678,https://example.com,東京都渋谷区,"営業, 決裁者",展示会で名刺交換,1,2026/4/12`)
check('日本語ヘッダを認識', jp.rows.length === 1, JSON.stringify(jp.rows))
const c = jp.rows[0]
check('氏名', c.name === '鈴木 一郎', c.name)
check('ふりがな', c.nameKana === 'すずき いちろう', c.nameKana)
check('会社名', c.company === '株式会社ライトスピード', c.company)
check('部署', c.department === '営業本部', c.department)
check('役職', c.position === '執行役員', c.position)
check('タグをカンマ分割', c.tags.length === 2 && c.tags[0] === '営業', JSON.stringify(c.tags))
check('お気に入り 1 → true', c.favorite === true, String(c.favorite))
check('日付 2026/4/12 → 2026-04-12', c.metAt === '2026-04-12', c.metAt)
check('Website にスキーム補完なし(既存)', c.website === 'https://example.com', c.website)

/* ---- 3. 英語ヘッダ ---- */
const en = csvToCards(`Name,Company,Department,Title,Email,Phone,Mobile,Website,Tags,Notes
John Smith,Acme Inc,Sales,Manager,john@acme.com,555-1234,,acme.com,"lead, vip",Met at expo`)
check('英語ヘッダを認識', en.rows.length === 1, JSON.stringify(en.rows))
check('英語→日本語フィールド', en.rows[0].name === 'John Smith' && en.rows[0].company === 'Acme Inc', JSON.stringify(en.rows[0]))
check('websiteにhttps補完', en.rows[0].website === 'https://acme.com', en.rows[0].website)

/* ---- 4. 表記ゆれ ---- */
const variants = csvToCards(`お名前,勤務先,所属,肩書き,メアド,ＴＥＬ,携帯,HP,所在地,ラベル,備考
山田 太郎,テスト株式会社,広報部,課長,taro@test.jp,03-0000-0000,090-0000-0000,test.jp,大阪府,"#重要, 新規",メモ内容`)
check('表記ゆれヘッダを吸収', variants.rows.length === 1, JSON.stringify(variants.rows))
check('「お名前」→氏名', variants.rows[0].name === '山田 太郎', variants.rows[0].name)
check('「勤務先」→会社', variants.rows[0].company === 'テスト株式会社', variants.rows[0].company)
check('「#重要」の#を除去', variants.rows[0].tags.includes('重要'), JSON.stringify(variants.rows[0].tags))

/* ---- 5. エラー行のスキップ ---- */
const withBad = csvToCards(`氏名,会社名
佐藤, A社
, B社
田中, C社`)
check('氏名が空の行をスキップ', withBad.rows.length === 2, `${withBad.rows.length}`)
check('スキップ理由を記録', withBad.skipped.length === 1 && withBad.skipped[0].line === 3, JSON.stringify(withBad.skipped))

/* ---- 6. ヘッダ無しCSVのフォールバック ---- */
const noHeader = csvToCards(`鈴木,ライト社
田中,ネクスト社`)
check('ヘッダ無しでも氏名列を推定しない(安全側)', noHeader.rows.length === 0 || noHeader.rows[0].name === '鈴木', JSON.stringify(noHeader.rows))

/* ---- 7. 重複キー ---- */
const k1 = duplicateKey('鈴木 一郎', '株式会社ライトスピード')
const k2 = duplicateKey('鈴木一郎', 'ライトスピード')
check('空白・法人格を無視して重複判定', k1 === k2, `${k1} vs ${k2}`)
const k3 = duplicateKey('鈴木 一郎', '別会社')
check('会社が違えば別人物', k1 !== k3)

/* ---- 8. 空CSV ---- */
const empty = csvToCards('')
check('空CSVで落ちない', empty.rows.length === 0, JSON.stringify(empty))

/* ---- 9. 壊れた引用符で無限ループしない ---- */
const broken = csvToCards('氏名,メモ\n"閉じない,メモ')
check('閉じない引用符でも停止する', Array.isArray(broken.rows))

console.log(`\n${failed === 0 ? 'すべてのCSVテストに合格' : failed + ' 件失敗'}`)
process.exit(failed ? 1 : 0)
