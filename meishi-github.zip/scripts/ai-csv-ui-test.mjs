/* AIアシスタントと CSV 取込の UI テスト。
   実際のサーバに接続して、DOM 上での操作と描画を検証する。 */
import { JSDOM, VirtualConsole } from 'jsdom'
import fs from 'node:fs'

const BASE = 'http://localhost:3000'
const meta = await (await fetch(BASE + '/api/meta')).json()
const TOTAL = meta.total

const html = await (await fetch(BASE + '/')).text()
const appJs = fs.readFileSync('public/static/app.js', 'utf8')
const css = fs.readFileSync('public/static/style.css', 'utf8')

const errors = []
const vc = new VirtualConsole()
vc.on('jsdomError', (e) => errors.push('jsdomError: ' + e.message))
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')))

const dom = new JSDOM(html, { url: BASE + '/', runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc })
const { window } = dom
const doc = window.document

// 作者CSSを読み込ませ、hidden が本当に効いているかまで見る
const style = doc.createElement('style')
style.textContent = css
doc.head.appendChild(style)

window.fetch = (input, init) => {
  const url = typeof input === 'string' && input.startsWith('/') ? BASE + input : input
  return fetch(url, init)
}
window.navigator.clipboard = { writeText: async () => {} }
window.confirm = () => true

const script = doc.createElement('script')
script.textContent = appJs
doc.body.appendChild(script)

const wait = (ms) => new Promise((r) => setTimeout(r, ms))
const q = (s) => doc.querySelector(s)
const qa = (s) => Array.from(doc.querySelectorAll(s))
const display = (sel) => {
  const el = q(sel)
  return el ? window.getComputedStyle(el).display : 'MISSING'
}

let failed = 0
function check(name, cond, extra = '') {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${cond ? '' : '  <-- ' + extra}`)
  if (!cond) failed += 1
}

await wait(1400)

console.log(`--- 前提: DB ${TOTAL}件 ---`)

/* ================= サイドバーの部署フィルタ ================= */
console.log('\n--- 部署フィルタ ---')
const deptItems = qa('#dept-filters [data-dept]')
check('部署リストが描画される', deptItems.length === meta.departments.length, `${deptItems.length} / ${meta.departments.length}`)

const targetDept = meta.departments[0]
const expectDept = (await (await fetch(`${BASE}/api/cards?department=${encodeURIComponent(targetDept)}`)).json()).total
q(`#dept-filters [data-dept="${targetDept}"]`)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check(`部署クリックで絞り込める (${targetDept} = ${expectDept}件)`, qa('.card').length === expectDept, `got ${qa('.card').length}`)
check('見出しに部署名が出る', (q('#result-title')?.textContent || '').includes(targetDept), q('#result-title')?.textContent)

// 解除
q(`#dept-filters [data-dept="${targetDept}"]`)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check('部署解除で全件に戻る', qa('.card').length === TOTAL, `got ${qa('.card').length}`)

// 部署 → タグの切り替えで排他になっているか
q(`#dept-filters [data-dept="${targetDept}"]`)?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(800)
qa('#tag-filters .chip')[0]?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)
check('部署→タグ切替で部署条件が解除される', !q(`#dept-filters [data-dept="${targetDept}"]`)?.classList.contains('is-active'))
qa('#tag-filters .chip')[0]?.dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(900)

/* ================= AI アシスタント ================= */
console.log('\n--- AIアシスタント ---')
check('AI起動ボタンがある', Boolean(q('#ai-fab')))
// パネルは display:flex のまま visibility で隠す設計なので、visibility で判定する
const aiHidden = window.getComputedStyle(q('#ai-panel')).visibility === 'hidden'
check('AIパネルは初期状態で非表示', aiHidden && !q('#ai-panel').classList.contains('is-open'),
  `visibility=${window.getComputedStyle(q('#ai-panel')).visibility}`)

q('#ai-fab').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(350)
check('AIパネルが開く', q('#ai-panel').classList.contains('is-open'))
check('開いたとき挨拶が出る', (q('#ai-log')?.textContent || '').length > 10, q('#ai-log')?.textContent?.slice(0, 40))
check('提案チップが並ぶ', qa('#ai-suggest [data-suggest]').length === 4, `${qa('#ai-suggest [data-suggest]').length}`)

// 実際にAIへ問い合わせる（「広報部署だけまとめて」）
q('#ai-input').value = '広報部署だけまとめて'
q('#ai-form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }))
await wait(200)
check('送信直後にユーザー発言が積まれる', (q('#ai-log')?.textContent || '').includes('広報部署だけまとめて'))
check('考え中のインジケータが出る', Boolean(q('.ai-typing')))

// AI応答を待つ（最大30秒）
let answered = false
for (let i = 0; i < 60; i += 1) {
  await wait(500)
  if (!q('.ai-typing') && qa('.ai-msg-bot').length >= 2) { answered = true; break }
}
check('AIが応答する', answered, q('#ai-log')?.textContent?.slice(-120))

const botText = qa('.ai-msg-bot').map((n) => n.textContent).join(' ')
check('応答に件数が含まれる', /\d+件/.test(botText), botText.slice(-100))

// AI が入力を反映して一覧が絞り込まれているか
const deptGuess = (await (await fetch(`${BASE}/api/cards?department=${encodeURIComponent('広報・マーケティング')}`)).json()).total
check('AIの指示で一覧が絞り込まれる（広報・マーケティング）', qa('.card').length === deptGuess, `${qa('.card').length} vs ${deptGuess}`)
check('AIの条件チップが表示される', qa('.ai-chip').length > 0, `${qa('.ai-chip').length}`)

q('#ai-close').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(300)
check('AIパネルが閉じる', !q('#ai-panel').classList.contains('is-open'))

/* ================= CSV 取込 ================= */
console.log('\n--- CSV取込 ---')
q('#import-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(300)
check('取込モーダルが開く', q('#import-backdrop').hidden === false)
check('ドロップゾーンがある', Boolean(q('#dropzone')))
check('初期状態では取込ボタンが無効', q('#import-commit').disabled === true)

// ファイル選択を模して、実際のCSVをプレビューさせる
const csvText = [
  '氏名,ふりがな,会社名,部署,役職,メール,タグ,名刺交換日',
  'UI検証AI 太郎,ゆーあい たろう,UIテスト商事,広報部,主任,ui-ai@example.com,"広報, 検証",2026/5/1',
  '鈴木 一郎,すずき いちろう,株式会社ライトスピード,営業本部,執行役員,ichiro@example.com,営業,2026-04-12',
  ', , 空行,,,,\n',
].join('\n')

const file = new window.File([csvText], 'test.csv', { type: 'text/csv' })
const fileInput = q('#file-input')
Object.defineProperty(fileInput, 'files', { value: [file], configurable: true })
fileInput.dispatchEvent(new window.Event('change', { bubbles: true }))

await wait(1500)
check('プレビューが表示される', q('#import-result').hidden === false)
check('統計に新規/重複が出る', (q('#import-stats')?.textContent || '').includes('新規'), q('#import-stats')?.textContent?.slice(0, 80))
check('プレビュー表に行が出る', qa('#import-table tbody tr').length >= 2, `${qa('#import-table tbody tr').length}`)
check('重複行がマークされる', qa('#import-table tr.is-dup').length === 1, `${qa('#import-table tr.is-dup').length}`)
check('列の対応が可視化される', qa('.map-chip').length > 3, `${qa('.map-chip').length}`)
check('取込ボタンが有効になる', q('#import-commit').disabled === false)

// 取込実行
q('#import-commit').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(2500)
check('取込後にモーダルが閉じる', q('#import-backdrop').hidden === true)

const afterMeta = await (await fetch(BASE + '/api/meta')).json()
check('新規1件だけ増える（重複はスキップ）', afterMeta.total === TOTAL + 1, `${afterMeta.total} (before ${TOTAL})`)

// 後片付け
const created = (await (await fetch(`${BASE}/api/cards?q=${encodeURIComponent('UI検証AI')}`)).json()).cards
for (const c of created) {
  await fetch(`${BASE}/api/cards/${c.id}`, { method: 'DELETE' })
}
const finalMeta = await (await fetch(BASE + '/api/meta')).json()
check('後片付けで元の件数に戻る', finalMeta.total === TOTAL, `${finalMeta.total}`)

/* ================= 空CSVのエラー処理 ================= */
console.log('\n--- 異常系 ---')
q('#import-btn').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(250)
const emptyFile = new window.File(['氏名,会社名\n'], 'empty.csv', { type: 'text/csv' })
Object.defineProperty(fileInput, 'files', { value: [emptyFile], configurable: true })
fileInput.dispatchEvent(new window.Event('change', { bubbles: true }))
await wait(1200)
check('データ行が無いCSVでエラーを表示', q('#import-error').hidden === false, q('#import-error').textContent)
q('#import-cancel').dispatchEvent(new window.MouseEvent('click', { bubbles: true }))
await wait(200)

console.log('\nJSエラー:', errors.length ? errors.slice(0, 5) : 'なし')
if (errors.length) failed += 1
console.log(failed === 0 ? 'すべてのAI/CSV UIテストに合格' : `${failed} 件失敗`)
process.exit(failed ? 1 : 0)
